<?php

	if(isset($_POST['cheminRepertoire'])) {

 	   $repertoire = opendir($_POST['cheminRepertoire']) or die('Erreur de listage : le répertoire n\'existe pas');
	   $fichiers = array();

	   while($contenu = readdir($repertoire)) {
	      if($contenu != '.' && $contenu != '..') {
	         if(!is_dir($_POST['cheminRepertoire'].'/'.$contenu)) {
	   	    $fichiers[] = $contenu;
	   	 }
	      }
	   }
	   closedir($repertoire);

	   if(!empty($fichiers)) {
	      sort($fichiers);
	      $jsonFichiers = json_encode($fichiers);
	      echo $jsonFichiers;
	   } else {
	      echo "null";
	   }
	}

?>