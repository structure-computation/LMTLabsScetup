<?php
	
	if(isset($_POST['cheminRepertoire']) && isset($_POST['nomRepertoire'])) {

	   function TailleRepertoire($repertoire) {
	
	      $repertoireRacine = opendir($repertoire);
	      $tailleRepertoire = 0;

	      while($contenu = readdir($repertoireRacine)) {
	         if(!in_array($contenu, array("..", "."))) {
	            if(is_dir($repertoire.'/'.$contenu)) {   
	               $tailleRepertoire += TailleRepertoire($repertoire.'/'.$contenu);
	            } else {
		       $tailleRepertoire += filesize($repertoire.'/'.$contenu);
		       clearstatcache();
		    }
	         }
	      }

	      closedir($repertoireRacine);
	      return $tailleRepertoire;
	   }
	   
	   echo TailleRepertoire($_POST['cheminRepertoire'].'/'.$_POST['nomRepertoire']);
	}
	
?>