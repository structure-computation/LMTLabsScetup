#!/bin/bash

clear

if [ -e `pwd`/installSiteGestionProcessus.sh ]
then

    if [ -e .variables.data ]
    then
	nomRepertoireFichiersSite=`more .variables.data | grep nomRepertoireFichiersSite | awk -F= '{print $2}'`
	cheminRepertoireApache=`more .variables.data | grep cheminRepertoireApache | awk -F= '{print $2}'`
	cheminRepertoireLocalhost=`more .variables.data | grep cheminRepertoireLocalhost | awk -F= '{print $2}'`
	nomUtilisateurApache=`more .variables.data | grep nomUtilisateurApache | awk -F= '{print $2}'`
    else
	echo "nomRepertoireFichiersSite=/siteGestionProcessus/" > .variables.data
	nomRepertoireFichiersSite=`more .variables.data | grep nomRepertoireFichiersSite | awk -F= '{print $2}'`
	echo "cheminRepertoireApache=/etc/apache2/" >> .variables.data
	cheminRepertoireApache=`more .variables.data | grep cheminRepertoireApache | awk -F= '{print $2}'`
	echo "cheminRepertoireLocalhost=/var/www/" >> .variables.data
	cheminRepertoireLocalhost=`more .variables.data | grep cheminRepertoireLocalhost | awk -F= '{print $2}'`
	echo "nomUtilisateurApache=www-data" >> .variables.data
	nomUtilisateurApache=`more .variables.data | grep nomUtilisateurApache | awk -F= '{print $2}'`
    fi

    isRunning=1
    while [ $isRunning -eq 1 ]
    do

	echo -e "\n\n"
	echo -e "\t**************************************************************"
	echo -e "\t*                                                            *"
	echo -e "\t*                    ***********************                 *"
	echo -e "\t*                    *                     *                 *"
	echo -e "\t*                    *         MENU        *                 *"
	echo -e "\t*                    *                     *                 *"
	echo -e "\t*                    ***********************                 *"
	echo -e "\t*                                                            *"
	echo -e "\t*                                                            *"
	echo -e "\t* Que voulez-vous faire ?                                    *"
	echo -e "\t* 1- Installer                                               *"
	echo -e "\t* 2- Désinstaller                                            *"
	echo -e "\t* 3- Restaurer les fichiers modifiés à l'état d'origine      *"
	echo -e "\t* 4- Connaître les fichiers à modifiés, modifiés et ajoutées *"
	echo -e "\t*                                                            *"
	echo -e "\t* 5- Redémmarer Apache                                       *"
	echo -e "\t* 6- Vérifier la syntaxe d'Apache                            *"
	echo -e "\t*                                                            *"
	echo -e "\t* 7- Quitter                                                 *"
	echo -e "\t*                                                            *"
	echo -e "\t**************************************************************\n"
	read -p "Choix ? " choix


	#############
	# INSTALLER #
	#############
	if [ $choix -eq 1 ]
	then

	    clear

	    # On vérifie que l'utilisateur est en mode root
	    if [ $UID -ne 0 ]
	    then
		echo -e "\nVous n'êtes pas root... Faites la commande \"sudo -s\" et relancez le script."
		echo -e "Arrêt de l'installation !\n"
	    elif [ $UID -eq 0 ]
	    then
		echo -e "\nVous êtes root, l'installation peut continuer..."

		# Installation des éléments	
		read -p "Voulez-vous poursuivre ? (o/n) " reponse
		if [ $reponse = o ]
		then

		    # Demande quelque informations concernant les fichiers du site
		    isOk=0
		    while [ $isOk -eq 0 ]
		    do
			read -p "Entrer le nom du répertoire contenant les fichiers du site : " repNomRepertoireFichiersSite
			if [ -d $repNomRepertoireFichiersSite ]
			then
			    if [ $reponse = o ]
			    then
				nomRepertoireFichiersSite=$repNomRepertoireFichiersSite
				echo "nomRepertoireFichiersSite=$nomRepertoireFichiersSite" > .variables.data
				echo "cheminRepertoireApache=$cheminRepertoireApache" >> .variables.data
				echo "cheminRepertoireLocalhost=$cheminRepertoireLocalhost" >> .variables.data
				echo "nomUtilisateurApache=$nomUtilisateurApache" >> .variables.data
				isOk=1
			    fi
			elif [ $reponse = n ]
			then
			    echo "Répertoire incorrect !!"
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done

		    
		    echo -e "\n\n\n\n"
		    echo "#######################"
		    echo "#                     #"
		    echo "#        APACHE       #"
		    echo "#                     #"
		    echo "#######################"

		    echo -e "\n"
		    # Installation d'Apache 2
		    pointille="************************************************"
		    but="Installation d'Apache 2"
		    commande="apt-get install apache2"
		    documentation=" - https://technique.arscenic.org/lamp-linux-apache-mysql-php/apache/article/la-gestion-des-modules\n - http://www.linux-france.org/prj/edu/archinet/systeme/ch16s02.html\n - http://doc.ubuntu-fr.org/apache2\n - http://php.net/manual/fr/install.php"
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande

		    echo -e "\n"
		    # Désactivation du mod passenger, car erreur au lancement à cause de passenger.load
		    pointille="************************************************"
		    but="Désactivation du mod passenger"
		    commande="a2dismod passenger"
		    documentation=""
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande

		    echo -e "\n"
		    # Démmarage d'Apache 2
		    pointille="************************************************"
		    but="Démmarage d'Apache 2"
		    commande="service apache2 start"
		    documentation=""
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande


		    echo -e "\n"
		    # Demande quelque informations concernant Apache
		    boucle=1
		    while [ $boucle -eq 1 ]
		    do
			read -p "Le chemin du répertoire contenant apache est bien : \"$cheminRepertoireApache\" ? (o/n) " reponse
			if [ $reponse = o ]
			then
			    boucle=0
			elif [ $reponse = n ]
			then
			    read -p "Entrer le chemin du répertoire contenant apache : " repCheminRepertoireApache
			    if [ -d $repCheminRepertoireApache ]
			    then
				cheminRepertoireApache=$repCheminRepertoireApache
				echo "nomRepertoireFichiersSite=$nomRepertoireFichiersSite" > .variables.data
				echo "cheminRepertoireApache=$cheminRepertoireApache" >> .variables.data
				echo "cheminRepertoireLocalhost=$cheminRepertoireLocalhost" >> .variables.data
				echo "nomUtilisateurApache=$nomUtilisateurApache" >> .variables.data
			    else
				echo "Chemin incorrect !!"
			    fi
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done


		    echo -e "\n"
		    # Demande quelque informations concernant Apache
		    boucle=1
		    while [ $boucle -eq 1 ]
		    do
			read -p "Le chemin du répertoire contenant les fichiers du localhost est bien : \"$cheminRepertoireLocalhost\" ? (o/n) " reponse
			if [ $reponse = o ]
			then
			    boucle=0
			elif [ $reponse = n ]
			then
			    read -p "Entrer le chemin du répertoire contenant les fichiers du localhost : " repCheminRepertoireLocalhost
			    if [ -d $repCheminRepertoireLocalhost ]
			    then
				cheminRepertoireLocalhost=$repCheminRepertoireLocalhost
				echo "nomRepertoireFichiersSite=$nomRepertoireFichiersSite" >. variables.data
				echo "cheminRepertoireApache=$cheminRepertoireApache" >> .variables.data
				echo "cheminRepertoireLocalhost=$cheminRepertoireLocalhost" >> .variables.data
				echo "nomUtilisateurApache=$nomUtilisateurApache" >> .variables.data
			    else
				echo "Chemin incorrect !!"
			    fi
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done


		    # Sauvegarde les fichiers qui vont être modifiés
		    pointille="************************************************"
		    but="Sauvegarde les fichiers qui vont être modifiés"
		    commandes=("cp $cheminRepertoireApache/ports.conf `pwd`/fichiersSauvegarde/" "cp /etc/sudoers `pwd`/fichiersSauvegarde/")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=""
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			$commande
		    done


		    echo -e "\n\n\n\n"
		    echo "#######################"
		    echo "#                     #"
		    echo "#        HTTPS        #"
		    echo "#                     #"
		    echo "#######################"

		    echo -e "\n"
		    # Installation de ssl, et des outils nécessaire pour le fonctionnement du https
		    pointille="************************************************"
		    but="Installation de ssl, et des outils nécessaire pour le fonctionnement du https"
		    commandes=("a2enmod ssl" "service apache2 force-reload" "apt-get install ssl-cert" "make-ssl-cert /usr/share/ssl-cert/ssleay.cnf /etc/ssl/private/localhost.pem" "openssl req -x509 -nodes -days 9999 -newkey rsa:1024 -out $cheminRepertoireApache/server.crt -keyout $cheminRepertoireApache/server.key" "chmod o-rw $cheminRepertoireApache/server.key")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=" - http://doc.ubuntu-fr.org/tutoriel/securiser_apache2_avec_ssl"
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			$commande
		    done


		    echo -e "\n\n\n\n"
		    echo "#######################"
		    echo "#                     #"
		    echo "#         PHP5        #"
		    echo "#                     #"
		    echo "#######################"

		    echo -e "\n"
		    # Installation de PHP5
		    pointille="************************************************"
		    but="Installation de PHP5"
		    commande="apt-get install libapache2-mod-php5 php5 php5-common php5-curl php5-dev php5-gd php5-idn php-pear php5-imagick php5-imap php5-json php5-mcrypt php5-memcache php5-mhash php5-ming php5-mysql php5-ps php5-pspell php5-recode php5-snmp php5-sqlite php5-tidy php5-xmlrpc php5-xsl"
		    documentation=""
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande

		    echo -e "\n"
		    # Activation de PHP5
		    pointille="************************************************"
		    but="Activation de PHP5"
		    commande="a2enmod php5"
		    documentation=""
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande

		    echo -e "\n"
		    # Certaine commande lancé avec shell_exec() de php ont besoin des permissions administrateur (sudo), l'ajout de ces lignes donne ces permissions à Apache (user www-data par défaut).
		    pointille="************************************************"
		    but="Configuration des permissions administrateur"
		    boucle=1
		    while [ $boucle -eq 1 ]
		    do
			ps -ef | grep apache2
			read -p "L'user est-il bien \"$nomUtilisateurApache\" pour Apache ? (o/n) " reponse
			if [ $reponse = o ]
			then
			    commande="echo -e \n#Lignes ajoutées pour le fonctionnement du site de gestion des processus (nécessaire pour exécuter des commandes php en mode sudo) !!\n$nomUtilisateurApache ALL=(ALL) NOPASSWD: ALL\n >> /etc/sudoers"
			    documentation=""
			    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			    echo -e $message
			    echo -e "\n#Lignes ajoutées pour le fonctionnement du site de gestion des processus (nécessaire pour exécuter des commandes php en mode sudo) !!\n$nomUtilisateurApache ALL=(ALL) NOPASSWD: ALL\n" >> /etc/sudoers
			    boucle=0
			elif [ $reponse = n ]
			then
			    read -p "Quel est le nom utilisateur d'Apache ? " nomUtilisateurApache
			    echo "nomRepertoireFichiersSite=$nomRepertoireFichiersSite" > .variables.data
			    echo "cheminRepertoireApache=$cheminRepertoireApache" >> .variables.data
			    echo "cheminRepertoireLocalhost=$cheminRepertoireLocalhost" >> .variables.data
			    echo "nomUtilisateurApache=$nomUtilisateurApache" >> .variables.data
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done
		    

		    echo -e "\n\n\n\n"
		    echo "#######################"
		    echo "#                     #"
		    echo "#     SHELLINABOX     #"
		    echo "#                     #"
		    echo "#######################"

		    echo -e "\n"
		    # Dézipage de ShellInABox
		    pointille="************************************************"
		    but="Dézipage de ShellInABox"
		    repertoireCourant=`pwd`

		    commandes=("cd $nomRepertoireFichiersSite/addon/" "unzip shellinabox-master.zip" "chmod -R 777 shellinabox-master")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=""
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			$commande
		    done
		    cd $repertoireCourant


		    echo -e "\n"
		    # Installation de ShellInABox et des outils nécessaire pour son installation
		    pointille="************************************************"
		    but="Installation de ShellInABox et des outils nécessaire pour son installation"
		    repertoireCourant=`pwd`
		    commandes=("cd $nomRepertoireFichiersSite/addon/shellinabox-master/" "apt-get install build-essential debhelper autotools-dev binutils libssl-dev libpam0g-dev zlib1g-dev" "apt-get install libssl0.9.8 libpam0g openssl" "./configure" "dpkg-buildpackage" "dpkg -i ../shellinabox_*.deb")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=" - https://code.google.com/p/shellinabox/wiki/shellinaboxd_man"
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			$commande
		    done
		    cd $repertoireCourant


		    echo -e "\n\n\n\n"
		    echo "#######################"
		    echo "#                     #"
		    echo "#        AUTRE        #"
		    echo "#                     #"
		    echo "#######################"

		    echo -e "\n"
		    # Met le code du site dans le répertoire contenant les fichiers du localhost, et donnes toutes les permissions au dossier du site
		    pointille="************************************************"
		    but="Met le code du site dans le répertoire contenant les fichiers du localhost, et donnes les permissions au dossier du site"
		    commandes=("cp -r $nomRepertoireFichiersSite $cheminRepertoireLocalhost/html/" "chmod -R 777 $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=""
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			$commande
		    done

		    echo -e "\n"
		    # Demande l'emplacement du fichier Makefile qui permet le lancement du processus 1
		    boucle=1
		    while [ $boucle -eq 1 ]
		    do
			if [ $cheminFichierMakeP1 != "" ]
			then
			    read -p "Le chemin du répertoire contenant le fichier Makefile du processus 1 est bien : \"$cheminFichierMakeP1\" ? (o/n) " reponse
			else
			    reponse=n;
			fi
			if [ $reponse = o ]
			then
			    boucle=0
			elif [ $reponse = n ]
			then
			    read -p "Entrer le chemin du répertoire contenant le fichier Makefile du processus 1 : " repCheminFichierMakeP1
			    if [ -d $repCheminFichierMakeP1 ]
			    then
				cheminFichierMakeP1=$repCheminFichierMakeP1
			    else
				echo "Chemin incorrect !!"
			    fi
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done

		    echo -e "\n"
		    # Demande l'emplacement du fichier Makefile qui permet le lancement du processus 2
		    boucle=1
		    while [ $boucle -eq 1 ]
		    do
			if [ $cheminFichierMakeP2 != "" ]
			then
			    read -p "Le chemin du répertoire contenant le fichier Makefile du processus 2 est bien : \"$cheminFichierMakeP2\" ? (o/n) " reponse
			else
			    reponse=n;
			fi
			if [ $reponse = o ]
			then
			    boucle=0
			elif [ $reponse = n ]
			then
			    read -p "Entrer le chemin du répertoire contenant le fichier Makefile du processus 2 : " repCheminFichierMakeP2
			    if [ -d $repCheminFichierMakeP2 ]
			    then
				cheminFichierMakeP2=$repCheminFichierMakeP2
			    else
				echo "Chemin incorrect !!"
			    fi
			elif [ $reponse != o ] || [ $reponse != n ]
			then
			    echo "Il faut répondre \"o\" ou \"n\" !!"
			fi
		    done
		    
		    # Création du fichier où est écrit les différents chemins des fichiers Makefile, dans le répertoire du site du localhost
		    echo "&cheminFichierMakeP1\&&cheminFichierMakeP2" > $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite/.variablesJS.data

		    echo -e "\n"
		    # Ajout du fichier de configuration exclusif au site, et active le site
		    pointille="************************************************"
		    but="Ajout du fichier de configuration exclusif au site, et active le site"
		    adresseIP=`ifconfig | grep 'inet adr:' | cut -d: -f2 | awk '{ print $1}' | head -n 1`
		    hostname="echo $HOSTNAME"
		    commandes=("echo -e <VirtualHost $adresseIP:80>\n\tServerName $hostname\n\tRedirect / https://$adresseIP/\n</VirtualHost>\n<VirtualHost $hostname:80>\n\tServerName $hostname\n\tRedirect / https://$adresseIP/\n</VirtualHost>\n\n<VirtualHost $adresseIP:443>\n\tServerName $hostname\n\tDocumentRoot $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite/\n\n\tSSLEngine on\n\tSSLCertificateFile $cheminRepertoireApache/server.crt\n\tSSLCertificateKeyFile $cheminRepertoireApache/server.key\n</VirtualHost>\n<VirtualHost $hostname:443>\n\tServerName $hostname\n\tDocumentRoot $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite/\n\n\tSSLEngine on\n\tSSLCertificateFile $cheminRepertoireApache/server.crt\n\tSSLCertificateKeyFile $cheminRepertoireApache/server.key\n</VirtualHost>\n > $cheminRepertoireApache/sites-available/sitegestionprocessus.conf" "cd $cheminRepertoireApache/sites-enabled/" "ln -s ../sites-available/sitegestionprocessus.conf  sitegestionprocessus.conf" "cd $repertoireCourant")
		    for i in `seq 0 ${#commandes[*]}`;
		    do
			commande=${commandes[i]}
			documentation=""
			message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
			echo -e $message
			if [ $i -eq 0 ]
			then
			    echo -e "<VirtualHost $adresseIP:80>\n\tServerName $hostname\n\tRedirect / https://$adresseIP/\n</VirtualHost>\n<VirtualHost $hostname:80>\n\tServerName $hostname\n\tRedirect / https://$adresseIP/\n</VirtualHost>\n\n<VirtualHost $adresseIP:443>\n\tServerName $hostname\n\tDocumentRoot $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite/\n\n\tSSLEngine on\n\tSSLCertificateFile $cheminRepertoireApache/server.crt\n\tSSLCertificateKeyFile $cheminRepertoireApache/server.key\n</VirtualHost>\n<VirtualHost $hostname:443>\n\tServerName $hostname\n\tDocumentRoot $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite/\n\n\tSSLEngine on\n\tSSLCertificateFile $cheminRepertoireApache/server.crt\n\tSSLCertificateKeyFile $cheminRepertoireApache/server.key\n</VirtualHost>\n > $cheminRepertoireApache/sites-available/sitegestionprocessus.conf"
			else
			    $commande
			fi
		    done

		    echo -e "\n"
		    # Redémmarage d'Apache 2
		    pointille="************************************************"
		    but="Redémmarage d'Apache 2"
		    commande="service apache2 restart"
		    documentation=""
		    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		    echo -e $message
		    $commande
		    

		    echo "Fin de l'installation !!"
		else
		    echo "Arrêt de l'installation !!"
		fi
	    fi

	    ################
	    # DESINSTALLER #
	    ################
	elif [ $choix -eq 2 ]
	then
	    clear
	    # Restaure les fichiers modifiés à l'état d'origine
	    pointille="************************************************"
	    but="Restaure les fichiers modifiés à l'état d'origine"
	    commandes=("cp `pwd`/fichiersSauvegarde/ports.conf $cheminRepertoireApache" "cp `pwd`/fichiersSauvegarde/ /etc/")
	    for i in `seq 0 ${#commandes[*]}`;
	    do
		commande=${commandes[i]}
		documentation=""
		message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		echo -e $message
		$commande
	    done

	    # Desinstallation
	    pointille="************************************************"
	    but="Desinstallation"
	    commandes=("rm $cheminRepertoireApache/server.crt" "rm $cheminRepertoireApache/server.key" "rm $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite" "rm $cheminRepertoireApache/sites-enabled/sitegestionprocessus.conf" "rm $cheminRepertoireApache/sites-available/sitegestionprocessus.conf" "service shellinabox stop" "apt-get remove shellinabox" "rm $nomRepertoireFichiersSite/addon/shellinabox_2.14-7*" "rm $nomRepertoireFichiersSite/addon/shellinabox-master/" "rm .variables.data")
	    for i in `seq 0 ${#commandes[*]}`;
	    do
		commande=${commandes[i]}
		documentation=""
		message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		echo -e $message
		$commande
	    done

	    echo -e "\n"
	    # Redémmarage d'Apache 2
	    pointille="************************************************"
	    but="Redémmarage d'Apache 2"
	    commande="service apache2 restart"
	    documentation=""
	    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
	    echo -e $message
	    $commande

	    ######################################################
	    # RESTAURER LES FICHIERS MODIFIES A L'ETAT D'ORIGINE #
	    ######################################################
	elif [ $choix -eq 3 ]
	then
	    clear
	    # Restaure les fichiers modifiés à l'état d'origine
	    pointille="************************************************"
	    but="Restaure les fichiers modifiés à l'état d'origine"
	    commandes=("cp `pwd`/fichiersSauvegarde/ports.conf $cheminRepertoireApache" "cp `pwd`/fichiersSauvegarde/ /etc/")
	    for i in `seq 0 ${#commandes[*]}`;
	    do
		commande=${commandes[i]}
		documentation=""
		message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
		echo -e $message
		$commande
	    done

	    echo -e "\n"
	    # Redémmarage d'Apache 2
	    pointille="************************************************"
	    but="Redémmarage d'Apache 2"
	    commande="service apache2 restart"
	    documentation=""
	    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
	    echo -e $message
	    $commande

	    #####################################
	    # CONNAITRE LES FICHIERS A MODIFIES #
	    #####################################
	elif [ $choix -eq 4 ]
	then
	    clear

	    echo "Fichiers à modifiés (si les lignes ne sont pas existantent) : "
	    echo -e "\t- $cheminRepertoireApache/ports.conf : \n\t#Lignes ajoutées pour le fonctionnement du site de gestion des processus (nécessaire pour la connexion sécurisée en https : permet à ce que apache écoute le port 443 si le module ssl est activé) !!\n\t<IfModule ssl_module>\n\t\tListen 443\n\t</IfModule>\n"
	    
	    echo "Fichiers modifiés : "
	    echo -e "\t- /etc/sudoers : \n\t#Lignes ajoutées pour le fonctionnement du site de gestion des processus (nécessaire pour exécuter des commandes php en mode sudo) !!\n\t$nomUtilisateurApache ALL=(ALL) NOPASSWD: ALL\n"

	    echo "Fichiers ajoutés : "
	    echo -e "\t- $cheminRepertoireApache/server.crt"
	    echo -e "\t- $cheminRepertoireApache/server.key"
	    echo -e "\t- $cheminRepertoireLocalhost/html/$nomRepertoireFichiersSite"
	    echo -e "\t- $cheminRepertoireApache/sites-available/sitegestionprocessus.conf"

	    #####################
	    # REDEMMARER APACHE #
	    #####################
	elif [ $choix -eq 5 ]
	then
	    clear
	    # Redémmarage d'Apache 2
	    pointille="************************************************"
	    but="Redémmarage d'Apache 2"
	    commande="service apache2 restart"
	    documentation=""
	    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
	    echo -e $message
	    $commande

	    ################################
	    # VERIFIER LA SYNTAXE D'APACHE #
	    ################################
	elif [ $choix -eq 6 ]
	then
	    clear
	    # Vérification de la syntaxe d'Apache
	    pointille="************************************************"
	    but="Vérification de la syntaxe d'Apache"
	    commande="apache2ctl -t"
	    documentation=""
	    message="\n$pointille\n\t$but\nLa commande effectuée est : \"$commande\"\nDocs :\n$documentation\n$pointille"
	    echo -e $message
	    $commande

	    ###########
	    # QUITTER #
	    ###########
	elif [ $choix -eq 7 ]
	then
	    isRunning=0
	    clear

	    ###################
	    # CHOIX INCORRECT #
	    ###################
	else
	    clear
	    echo "Choix \"$choix\" incorrect !!"

	fi
    done

else
    echo -e "\nATTENTION !! Exécuté ce script à partir du dossier le contenant.\nArrêt du script !\n"
fi
