#include <Soca/Com/SodaClient.h>
#include <Soca/Model/TypedArray.h>
#include <QtCore/QFile>
#include <QtCore/QTemporaryFile>
#include <QtCore/QDataStream>
#include "BlankUpdater.h"


bool BlankUpdater::run( MP mp ) {
    
    MP ch = mp[ "_children[ 0 ]" ];
    
}



