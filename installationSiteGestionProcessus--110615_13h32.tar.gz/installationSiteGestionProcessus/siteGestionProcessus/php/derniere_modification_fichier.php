<?php
	
	if(isset($_POST['cheminRepertoire']) && isset($_POST['nomFichier'])) {
	
	   $fichier = $_POST['cheminRepertoire'].'/'.$_POST['nomFichier'];
	   if(file_exists($fichier)) {
	      echo sha1_file($fichier);
     	   }
	}

?>