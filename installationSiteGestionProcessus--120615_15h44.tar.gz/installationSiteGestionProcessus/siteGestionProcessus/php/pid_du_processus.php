<?php

	if(isset($_POST['nomProcessus'])) {
	   
	   $fichier = '../tmp/liste_processus.txt';

	   $cmd = shell_exec('ps -ef > '.$nomFichier);
	   $fichierToTab = file($fichier); // Récupèration du fichier dans un tableau avec une ligne par cellule

	   foreach($fichierToTab as $numeroLigne => $contenuLigne) {
	      $isMatch = preg_match("#".$_POST['nomProcessus']."#", $contenuLigne); // Retourne 1 si la chaîne est trouvé, 0 sinon.
	      if($isMatch == 1) {
		 $contenuLigneExplode = explode(" ", $contenuLigne);
		 for($i = 1; $i < count($contenuLigneExplode); $i++) {
		    if($contenuLigneExplode[$i] != "") {
		       echo $contenuLigneExplode[$i]; // Ici, $contenuLigneExplode[$i] est le pid
		       break;
		    }
		 }
		 break;
	      }
	   }
	}

?>