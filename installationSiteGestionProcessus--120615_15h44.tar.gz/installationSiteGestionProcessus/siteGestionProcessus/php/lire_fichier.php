<?php

	if(isset($_POST['cheminRepertoire']) && isset($_POST['nomFichier'])) {

	   $fichier = file_get_contents($_POST['cheminRepertoire'].'/'.$_POST['nomFichier']);
	   echo $fichier;
	}

?>