// ----------------------------------------------------------
// Récupère la taille d'un élément quelque soit le navigateur
// ----------------------------------------------------------
function obtenirHauteurElement(idElement) {

    var hauteurElement;
    var element = document.getElementById(idElement);

    if(element.offsetHeight) {
	hauteurElement = element.offsetHeight;
    } else if(element.style.pixelHeight) {
	hauteurElement = element.style.pixelHeight;
    }
    return hauteurElement;
}
// ----------------------------------------------------------
// ----------------------------------------------------------




$(function() {

    // -------------------------------------------------
    // Permet le redimensionnement de différents élément
    // -------------------------------------------------
    function redimensionnerHauteur() {

	var hauteur;
	if(typeof(window.innerWidth) == 'number') {
	    hauteur = window.innerHeight;
	} else if(document.documentElement && document.documentElement.clientHeight) {
	    hauteur = document.documentElement.clientHeight;
	}
	
	var heightDivGauche;
	var divGauche = document.getElementById("div_gauche");
	heightDivGauche = parseInt(hauteur) - 63;
	divGauche.style.height = heightDivGauche + "px";

	var heightDivBoutons;
	var divBoutons = document.getElementById("div_boutons");
	heightDivBoutons = parseInt(obtenirHauteurElement("boutons_p1")) + parseInt(obtenirHauteurElement("boutons_p2")) + parseInt(obtenirHauteurElement("boutons_p1_p2")) + 15 + 15 + 15;
	divBoutons.style.height = heightDivBoutons + "px";

	var heightDivAlerteEtProgressBarP1;
	var divAlerteEtProgressBarP1 = document.getElementById("div_alerte_et_progress_bar_p1");
	heightDivAlerteEtProgressBarP1 = heightDivGauche - parseInt(obtenirHauteurElement("div_boutons")) - parseInt(obtenirHauteurElement("div_footer_gauche"));
	divAlerteEtProgressBarP1.style.height = heightDivAlerteEtProgressBarP1 + "px";

	var divAlerteEtProgressBarP2 = document.getElementById("div_alerte_et_progress_bar_p2");
	divAlerteEtProgressBarP2.style.height = heightDivAlerteEtProgressBarP1 + "px";

	var heightDivTraitVertical;
	var divTraitVertical = document.getElementById("div_trait_vertical");
	heightDivTraitVertical = parseInt(hauteur) - 63;
	divTraitVertical.style.height = heightDivTraitVertical + "px";

	var heightDivDroite;
	var divDroite = document.getElementById("div_droite");
	heightDivDroite = parseInt(hauteur) - 63;
	divDroite.style.height = heightDivDroite + "px";

	var heightDivLogsEtTerminal;
	var divLogsEtTerminal = document.getElementById("div_logs_et_terminal");
	heightDivLogsEtTerminal = parseInt(heightDivDroite - 42);
	divLogsEtTerminal.style.height = heightDivLogsEtTerminal + "px";

	var ddlLogsContentCss = document.getElementById("ddl_logs_content_css");
	ddlLogsContentCss.style.height = heightDivLogsEtTerminal + "px";

	var heightModalBodyDdlLogs;
	var modalBodyDdlLogs = document.getElementById("modal_body_ddl_logs");
	heightModalBodyDdlLogs = heightDivLogsEtTerminal - parseInt(obtenirHauteurElement("modal_header_ddl_logs")) - parseInt(obtenirHauteurElement("modal_footer_ddl_logs"));
	modalBodyDdlLogs.style.height = heightModalBodyDdlLogs + "px";
	
	var heightUlDropdownMenu;
	var ulDropdownMenu = document.getElementById("ul_dropdown_menu");
	heightUlDropdownMenu = heightDivLogsEtTerminal / 2;
	ulDropdownMenu.style.maxHeight = heightUlDropdownMenu + "px";
    }

    // Appel de la fonction height lors du chargement de la page
    window.onload = function() {
	redimensionnerHauteur();
    }
    // Appel de la fonction height lors du redimmensionnement de la page
    window.onresize = function() {
	redimensionnerHauteur();
    } 
    
    // Redimensionne la fenêtre lorsque le popin de ddl des logs est affiché afin que la balise pre soit à la bonne taille.
    $("#id_popin_ddl_logs").on('shown.bs.modal', function() {
	redimensionnerHauteur();
    });
    // -------------------------------------------------
    // -------------------------------------------------
});
