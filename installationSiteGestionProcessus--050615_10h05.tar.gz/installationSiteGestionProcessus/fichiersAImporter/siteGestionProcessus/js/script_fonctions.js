// ----------------------------------------------------------
// Fonction permettant l'affichage d'un popin de confirmation
// ----------------------------------------------------------
function popinDemanderConfirmation(titre, message, callbacks) {

    var estConfirme = false;

    var body = document.getElementsByTagName('body')[0];

    var divGlobalConfirmation = document.createElement('div');
    divGlobalConfirmation.setAttribute("id", "div_global_confirmation");
    body.appendChild(divGlobalConfirmation);

    var popinConfirmation =  document.createElement('div');
    popinConfirmation.setAttribute("class", "modal fade");
    popinConfirmation.setAttribute("tabindex", "-1");
    popinConfirmation.setAttribute("role", "dialog");
    popinConfirmation.setAttribute("aria-labelledby", "titrePopUp");
    popinConfirmation.setAttribute("aria-hidden", "true");
    divGlobalConfirmation.appendChild(popinConfirmation);

    var modalDialog = document.createElement('div');
    modalDialog.setAttribute("class", "modal-dialog");
    popinConfirmation.appendChild(modalDialog);

    var modalContent = document.createElement('div');
    modalContent.setAttribute("class", "modal-content");
    modalDialog.appendChild(modalContent);

    var modalHeader = document.createElement('div');
    modalHeader.setAttribute("class", "modal-header");
    modalContent.appendChild(modalHeader);
    var modalTitle = document.createElement('h4');
    modalTitle.setAttribute("class", "modal-title");
    modalTitle.innerHTML = titre;
    modalHeader.appendChild(modalTitle);
    var boutonCroixFermeture = document.createElement('button');
    boutonCroixFermeture.setAttribute("type", "button");
    boutonCroixFermeture.setAttribute("class", "close");
    boutonCroixFermeture.setAttribute("data-dismiss", "modal");
    boutonCroixFermeture.setAttribute("aria-hidden", "true");
    boutonCroixFermeture.innerHTML = "&times;";
    modalTitle.appendChild(boutonCroixFermeture);

    var modalBody = document.createElement('div');
    modalBody.setAttribute("class", "modal-body");
    modalContent.appendChild(modalBody);
    var pMessagePopinConfirmation = document.createElement('p');
    pMessagePopinConfirmation.innerHTML = message;
    modalBody.appendChild(pMessagePopinConfirmation);
    var boutonConfirmation = document.createElement('button');
    boutonConfirmation.setAttribute("class", "btn btn-success");
    boutonConfirmation.innerHTML = "Confirmer";
    boutonConfirmation.style.marginRight = "5px";
    boutonConfirmation.onclick = function() {
	callbacks[0]();
	estConfirme = true;
	$(popinConfirmation).modal("hide");
    };
    modalBody.appendChild(boutonConfirmation);
    var boutonAnnulation = document.createElement('button');
    boutonAnnulation.setAttribute("class", "btn btn-danger");
    boutonAnnulation.innerHTML = "Annuler";
    boutonAnnulation.onclick = function() {
	$(popinConfirmation).modal("hide");
    };
    modalBody.appendChild(boutonAnnulation);

    var modalFooter = document.createElement('div');
    modalFooter.setAttribute("class", "modal-footer");
    modalContent.appendChild(modalFooter);
    var boutonFermer = document.createElement('button');
    boutonFermer.setAttribute("class", "btn btn-info");
    boutonFermer.setAttribute("data-dismiss", "modal");
    boutonFermer.setAttribute("aria-hidden", "true");
    boutonFermer.innerHTML = "Fermer";
    modalFooter.appendChild(boutonFermer);


    $(popinConfirmation).ready(function() {
	$(popinConfirmation).modal("show");
    });

    $(popinConfirmation).on('hidden.bs.modal', function() {
	if(callbacks[1] != null && estConfirme == false) {
            callbacks[1]();
        }
	document.getElementsByTagName('body')[0].removeChild(divGlobalConfirmation);
    });
}
// ----------------------------------------------------------
// ----------------------------------------------------------




// ----------------------------------------------------------
// Récupération de l'url afin d'en extraire le nom de domaine
// ----------------------------------------------------------
function domaine() { 
    var url = document.URL;
    var urlSplit = url.split('/');
    return urlSplit[2];
}
// ----------------------------------------------------------
// ----------------------------------------------------------




// ------------------------------------------------------------
// Fonction permettant de connaitre la date et l'heure actuelle
// ------------------------------------------------------------
function dateActuelle() {

    var date = new Date();
    var annee = date.getFullYear();
    var moisTmp = parseInt(date.getMonth()) + 1;
    var mois = ('0' + moisTmp).slice(-2);
    var jour = ('0' + date.getDate()).slice(-2);
    var heure = ('0' + date.getHours()).slice(-2);
    var minute = ('0' + date.getMinutes()).slice(-2);
    var seconde = ('0' + date.getSeconds()).slice(-2);

    return "_" + annee + mois + jour + heure + minute + seconde;
}
// ------------------------------------------------------------
// ------------------------------------------------------------




// -------------------------------------------
// Fonction permettant d'exécuter une commande
// -------------------------------------------
function lancerCommande(cheminDuRepertoire, commandeALancer) {

    var resultatCmd;

    $.ajax({
	async: false,
	url: '/php/lancer_commande.php',
	type: 'post',
	data: 'repertoire=' + cheminDuRepertoire + '&commande=' + commandeALancer,
	typeData: 'html',
	success: function(valeurRetour) {
	    resultatCmd = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return resultatCmd;
}
// -------------------------------------------
// -------------------------------------------




// --------------------------------------
// Fonction permettant de lire un fichier
// --------------------------------------
function lireFichier(cheminRepertoire, nomFichier) {

    var contenuDuFichier;

    $.ajax({
	async: false,
	url: '/php/lire_fichier.php',
	type: 'post',
	data: 'cheminRepertoire=' + cheminRepertoire  + '&nomFichier=' + nomFichier,
	typeData: 'html',
	success: function(valeurRetour) {
	    contenuDuFichier = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return contenuDuFichier;
}
// --------------------------------------
// --------------------------------------




// -----------------------------------------------------------------------------------------------------------
// Fonction permettant d'avoir les dernières modifications d'un fichier au format sha1 (Secure Hash Algorithm)
// -----------------------------------------------------------------------------------------------------------
function derniereModificationFichier(cheminRepertoire, nomFichier) {
    
    var derniereMoficationHasher;

    $.ajax({
	async: false,
	url: '/php/derniere_modification_fichier.php',
	type: 'post',
	data: 'cheminRepertoire=' + cheminRepertoire  + '&nomFichier=' + nomFichier,
	typeData: 'html',
	success: function(valeurRetour) {
	    derniereMoficationHasher = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return derniereMoficationHasher;
}
// -----------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------




// ------------------------------------------------------------
// Fonction permettant de savoir si un processus X est en cours
// ------------------------------------------------------------
function trouverSiProcessusExiste(nomProcessus) {

    var estExistant;

    $.ajax({
	async: false,
	url: '/php/trouver_si_processus_existe.php',
	type: 'post',
	data: 'nomProcessus=' + nomProcessus,
	typeData: 'html',
	success: function(valeurRetour) {
	    estExistant = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return estExistant;
}
// ------------------------------------------------------------
// ------------------------------------------------------------




// -----------------------------------------------------
// Fonction permettant de savoir le pid d'un processus X
// -----------------------------------------------------
function pidDuProcessus(nomProcessus) {

    var pid;

    $.ajax({
	async: false,
	url: '/php/pid_du_processus.php',
	type: 'post',
	data: 'nomProcessus=' + nomProcessus,
	typeData: 'html',
	success: function(valeurRetour) {
	    pid = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return pid;
}
// -----------------------------------------------------
// -----------------------------------------------------




// --------------------------------------------------------
// Fonction permettant de savoir le contenu d'un répertoire
// --------------------------------------------------------
function listerContenuRepertoire(cheminRepertoire) {

    var contenuDuRepertoire;

    $.ajax({
    	async: false,
	url: '/php/lister_contenu_repertoire.php',
	type: 'post',
	data: 'cheminRepertoire=' + cheminRepertoire,
	typeData: 'html',
	success: function(valeurRetour) {
	    if(valeurRetour != "null") {
		contenuDuRepertoire = JSON.parse(valeurRetour);
	    } else {
		contenuDuRepertoire = null;
	    }
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return contenuDuRepertoire;
}
// --------------------------------------------------------
// --------------------------------------------------------




// ----------------------------------------------------------------
// Fonction permettant de savoir la taille d'un repertoire en octet
// ----------------------------------------------------------------
function tailleRepertoire(cheminRepertoire, nomRepertoire) {
    
    var tailleRepertoire;

    $.ajax({
    	async: false,
	url: '/php/taille_repertoire.php',
	type: 'post',
	data: 'cheminRepertoire=' + cheminRepertoire  + '&nomRepertoire=' + nomRepertoire,
	typeData: 'html',
	success: function(valeurRetour) {
	    tailleRepertoire = valeurRetour;
	},
	error: function(statut) {
	    console.log(statut);
	}
    });
    return tailleRepertoire;
}
// ----------------------------------------------------------------
// ----------------------------------------------------------------




// -------------------------------------
// Fonction de clignotement d'un élément
// -------------------------------------
function clignotement(idElement) {

    var element = document.getElementById(idElement);
    element.setAttribute("data-isclignotant", "true");
    
    var clignotement = setInterval(function() {
	if($(element).attr("data-isclignotant") == "true") {
	    if(element.style.opacity == 0) {
		element.style.opacity = 1;
	    } else {
		element.style.opacity = 0;
	    }
	} else {
	    element.style.opacity = 1;
	    clearInterval(clignotement);
	}
    }, 750);
}
// -------------------------------------
// -------------------------------------




// ----------------------------------------------------------------------------------------------------
// Permet de faire clignoter le glyphicon des logs pour indiquer à l'utilisateur si les logs on été maj
// ----------------------------------------------------------------------------------------------------
function faireClignoterGlyphIconLogs(idOngletLogs, idGlyphConteneur) {
    
    var ongletLogs = document.getElementById(idOngletLogs);

    if(ongletLogs.className != "active") {
	if($('#' + idGlyphConteneur).attr("data-isclignotant") == "false") {
	    clignotement(idGlyphConteneur);
	}
    }
}
// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------




// --------------------------------------------------------
// Classe permettant la mise à jour des affichages des logs
// --------------------------------------------------------
var MajLogs = function(cheminRepertoireLogs, tableauIdConteneur, tableauIdOngletLogs, tableauIdGlyphConteneur) {

    var nomFichiersLogs = new Array();
    var contenuRepertoireLogs = listerContenuRepertoire("../tmp/logs/");
    if(contenuRepertoireLogs != null) {
	for(var i = 0; i < contenuRepertoireLogs.length; i++) {
	    var tmpTab = contenuRepertoireLogs[i].split('_');
	    if(tmpTab[0] == "logsBdd") {
		nomFichiersLogs[0] = contenuRepertoireLogs[i];
	    } else if(tmpTab[0] == "logsServeurCalcul") {
		nomFichiersLogs[1] = contenuRepertoireLogs[i];
	    }
	}
    }

    var tableauDerniereModificationHasher = new Array();
    setInterval(function () {

	for(var i = 0; i < tableauIdConteneur.length; i++) {

	    var tableauTmp = new Array();
	    tableauTmp[i] = derniereModificationFichier(cheminRepertoireLogs, nomFichiersLogs[i]);

	    if(tableauDerniereModificationHasher[i] != tableauTmp[i]) {
		var conteneur = document.getElementById(tableauIdConteneur[i]);
		$(conteneur).empty();
		conteneur.innerHTML = lireFichier(cheminRepertoireLogs, nomFichiersLogs[i]);
		conteneur.scrollTop = conteneur.scrollHeight;
		faireClignoterGlyphIconLogs(tableauIdOngletLogs[i], tableauIdGlyphConteneur[i]);

		tableauDerniereModificationHasher[i] = tableauTmp[i]
	    }
	}
    }, 1000);

    this.setNomFichiersLogs = function(indice, newNomFichierLogs) {
	nomFichiersLogs[indice] = newNomFichierLogs;
    }

    this.getNomFichiersLogs = function() {
	return nomFichiersLogs;
    }
}
// --------------------------------------------------------
// --------------------------------------------------------




// -------------------------------------------------------------------
// Gestion du rafraichissement du badge qui indique le nombre d'alerte
// -------------------------------------------------------------------
function majBadgeAlerte(idBadge, idConteneur) {

    var badge = document.getElementById(idBadge);
    badge.setAttribute("data-isrunning", "true");
    $(badge).empty();

    badge.innerHTML = "1 alerte";

    var actionInterval = null;
    actionInterval = setInterval(function() {
	if(badge.innerHTML = document.getElementById(idConteneur).childNodes.length == 0) {
	    badge.innerHTML = "0 alerte";
	    badge.setAttribute("data-isrunning", "false");
	    clearInterval(actionInterval);
	} else if(badge.innerHTML = document.getElementById(idConteneur).childNodes.length == 1) {
	    badge.innerHTML = "1 alerte";
	} else {
	    badge.innerHTML = document.getElementById(idConteneur).childNodes.length + " alertes";
	}
    }, 1);
}
// -------------------------------------------------------------------
// -------------------------------------------------------------------




// ----------------------
// Affichage d'une alerte
// ----------------------
function afficherAlerte(idConteneur, type, contenuStrong, contenu, idBadge) {

    var conteneur = document.getElementById(idConteneur);

    var divAlerte = document.createElement('div');
    divAlerte.setAttribute("id", "div_alerte");
    divAlerte.setAttribute("class", "alert alert-dismissable alert-" + type);
    conteneur.appendChild(divAlerte);

    var buttonCloseAlerte = document.createElement('button');
    buttonCloseAlerte.setAttribute("type", "button");
    buttonCloseAlerte.setAttribute("class", "close");
    buttonCloseAlerte.setAttribute("data-dismiss", "alert");
    buttonCloseAlerte.setAttribute("aria-hidden", "true");
    buttonCloseAlerte.innerHTML = '&times;';
    divAlerte.appendChild(buttonCloseAlerte);

    var contenuAlerte = document.createElement('p');
    contenuAlerte.innerHTML = '<strong>' + contenuStrong + '</strong> ' + contenu;
    divAlerte.appendChild(contenuAlerte);

    conteneur.parentNode.scrollTop = conteneur.parentNode.scrollHeight;

    $(divAlerte).ready(function() {
	if($('#' + idBadge).attr("data-isrunning") == "false") {
	    $('#' + idBadge).attr("data-isrunning", "true");
	    majBadgeAlerte(idBadge, idConteneur);
	}
	var opacite = 1;
	var actionInterval = null;
	setTimeout(function() {
	    actionInterval = setInterval(function() {
		opacite -= 0.05;
		divAlerte.style.opacity = opacite;
                if(opacite <= 0) {
		    $(divAlerte).remove();
		    clearInterval(actionInterval);
                }
	    }, 50);
	}, 5000);
    });

    afficherEtatProcessus(['ext/Soda/soda', 'LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe'], ['span_etat_p1', 'span_etat_p2'], false);
}
// ----------------------
// ----------------------




// -------------------------------------------------
// Gestion de l'affichage de la barre de progression
// -------------------------------------------------
function afficherBarreProgression(idConteneur) {

    var conteneur = document.getElementById(idConteneur);
    conteneur.setAttribute("style", "display: block;");

    var divBarreProgression = document.createElement('div');
    divBarreProgression.setAttribute("id", "div_barre_progression");
    divBarreProgression.setAttribute("class", "progress-bar progress-bar-success progress-bar-striped active");
    divBarreProgression.setAttribute("role", "progressbar");
    divBarreProgression.setAttribute("aria-valuenow", "0");
    divBarreProgression.setAttribute("aria-valuemin", "0");
    divBarreProgression.setAttribute("aria-valuemax", "100");
    divBarreProgression.setAttribute("style", "width: 0%;");
    conteneur.appendChild(divBarreProgression);

    conteneur.parentNode.scrollTop = conteneur.parentNode.scrollHeight;

    $(divBarreProgression).ready(function() {
	var progression = 0;
	var actionInterval = null;
	actionInterval = setInterval(function() {
	    progression += (100 / 5);
	    divBarreProgression.setAttribute("aria-valuenow", progression);
	    divBarreProgression.style.width = progression + "%";
            if(progression >= 100) {
		$(divBarreProgression).remove();
		conteneur.setAttribute("style", "display: none;");
		clearInterval(actionInterval);
            }
	}, 1000);
    });
}
// -------------------------------------------------
// -------------------------------------------------




// -------------------------------------------------------
// Permet d'indiquer à l'utilisateur l'état d'un processus
// -------------------------------------------------------
function afficherEtatProcessus(tableauNomProcessus, tableauIdConteneur, estRecursif) {
    
    for(var i = 0; i < tableauNomProcessus.length; i++) {

	var etatProcessus = trouverSiProcessusExiste(tableauNomProcessus[i]);
	var conteneur = document.getElementById(tableauIdConteneur[i]);

	if(etatProcessus == 1) {
	    conteneur.setAttribute("class", "glyphicon glyphicon-ok");
	    conteneur.setAttribute("style", "color: green;");
	} else if(etatProcessus == 0) {
	    conteneur.setAttribute("class", "glyphicon glyphicon-remove");
	    conteneur.setAttribute("style", "color: red;");
	}	
    }

    if(estRecursif == true) {
	setTimeout(function() {
	    afficherEtatProcessus(tableauNomProcessus, tableauIdConteneur, true);
	}, 60000);
    }
}
// -------------------------------------------------------
// -------------------------------------------------------




// -------------------------------------------------------------
// Fonction permettant de gérer la suppression des fichiers logs
// -------------------------------------------------------------
function supprimerHistoriqueLogs(cheminRepertoire, nomRepertoire, nomFichier) {

    while(tailleRepertoire(cheminRepertoire, nomRepertoire) >= 50000000) { // 50Mo

	var contenuRepertoireHistoriqueLogs = listerContenuRepertoire(cheminRepertoire + '/' + nomRepertoire);

	if(contenuRepertoireHistoriqueLogs != null) {
	    var dates = new Array();
	    for(var i = 0; i < contenuRepertoireHistoriqueLogs.length; i++) {
		var tmpTab = contenuRepertoireHistoriqueLogs[i].split('_');
		var tmpTabSplit = tmpTab[1].split('.');
		dates.push(tmpTabSplit[0]);
	    }

	    dates.sort(function (a, b) {
		if (a < b) {
		    return -1;
		} else if (a > b) {
		    return 1;
		} else {
		    return 0;
		}
	    });

	    lancerCommande(cheminRepertoire + '/' + nomRepertoire, "rm " + nomFichier + "_" + dates[0] + ".log");
	}
    }
}
// -------------------------------------------------------------
// -------------------------------------------------------------




// -----------------------------------------------------------------------------------------------------------------------------------------
// Fonction permettant de gérer le déplacement d'un log actuel dans le repertoire d'hitorique et appel la fonction supprimerHistoriqueLogs()
// -----------------------------------------------------------------------------------------------------------------------------------------
function deplacementLogs(numProcessus) {
    
    var contenuRepertoireLogs = listerContenuRepertoire("../tmp/logs/");
    
    if (contenuRepertoireLogs != null) {
	for(var i = 0; i < contenuRepertoireLogs.length; i++) {
	    var tmpTab = contenuRepertoireLogs[i].split('_');
	    if(numProcessus == 1 && tmpTab[0] == "logsBdd") {
		lancerCommande(".", "mv ../tmp/logs/" + contenuRepertoireLogs[i] + " ../tmp/historiqueLogs/logs1/");
		supprimerHistoriqueLogs("../tmp/historiqueLogs/", "logs1/", tmpTab[0]);
	    } else if(numProcessus == 2 && tmpTab[0] == "logsServeurCalcul") {
		lancerCommande(".", "mv ../tmp/logs/" + contenuRepertoireLogs[i] + " ../tmp/historiqueLogs/logs2/");
		supprimerHistoriqueLogs("../tmp/historiqueLogs/", "logs2/", tmpTab[0]);
	    }
	}
    }
}
// -----------------------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------------------




// -----------------------------------------------
// Permet d'activer les boutons passé en paramètre
// -----------------------------------------------
function activerBoutons(tableauDeIdBoutons) {

    for(var i = 0; i < tableauDeIdBoutons.length; i++) {	
	$('#' + tableauDeIdBoutons[i]).removeClass("disabled");
    }
}
// -----------------------------------------------
// -----------------------------------------------




// ---------------------------------------------------
// Permet de désactiver les boutons passé en paramètre
// ---------------------------------------------------
function desactiverBoutons(tableauDeIdBoutons) {

    for(var i = 0; i < tableauDeIdBoutons.length; i++) {	
	$('#' + tableauDeIdBoutons[i]).addClass("disabled");
    }
}
// ---------------------------------------------------
// ---------------------------------------------------




$(function() {


    // ------------------------------------
    // Mise à jours de l'état des processus
    // ------------------------------------
    $(document.getElementById('span_etat_p1')).ready(function() {
    	$(document.getElementById('span_etat_p2')).ready(function() {
	    afficherEtatProcessus(['ext/Soda/soda', 'LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe'], ['span_etat_p1', 'span_etat_p2'], true);
	});
    });
    // ------------------------------------
    // ------------------------------------



    // ---------------------
    // Mise à jours des logs
    // ---------------------
    var majLogs;
    $(document.getElementById('pre_affichage_logs_1')).ready(function() {
	$(document.getElementById('pre_affichage_logs_2')).ready(function() {
	    majLogs = new MajLogs("../tmp/logs/", ['pre_affichage_logs_1', 'pre_affichage_logs_2'], ['onglet_affichage_logs_1', 'onglet_affichage_logs_2'], ['span_affichage_logs_1', 'span_affichage_logs_2']);
	});
    });
    // ---------------------
    // ---------------------



    // --------------------------------------------------------------------
    // Lorsque qu'un element avec la class btn obtient le focus, il le perd
    // --------------------------------------------------------------------
    $(document.getElementsByClassName('btn')).focus(function() {
	this.blur();
    });
    // --------------------------------------------------------------------
    // --------------------------------------------------------------------



    // ----------------------------------
    // Permet le rechargement du terminal
    // ----------------------------------
    $('#recharger_terminal').click(function() {

	var divTerminal = document.getElementById('div_terminal');
	$('#iframe_terminal').remove();
	var iframeTerminal = document.createElement('iframe');
	iframeTerminal.setAttribute("id", "iframe_terminal");
	iframeTerminal.setAttribute("src", "https://" + domaine() + ":6175/");
	divTerminal.appendChild(iframeTerminal);
    });
    // ----------------------------------
    // ----------------------------------
    


    // ----------------------------------------------------------------------------------
    // Permet la maj de l'état des processus lors de l'appuie sur le bouton correspondant
    // ----------------------------------------------------------------------------------
    $('#etat_processus').click(function() {
    	afficherEtatProcessus(['ext/Soda/soda', 'LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe'], ['span_etat_p1', 'span_etat_p2'], false);
    });
    // ----------------------------------------------------------------------------------
    // ----------------------------------------------------------------------------------



    // -----------------------------------------------
    // Gestion de l'affichage du PopIn de ddl des logs
    // -----------------------------------------------
    $('#ddl_logs').click(function() {

	var pTitrePopinDdlLogs = document.getElementById('p_titre_popin_ddl_logs');
	pTitrePopinDdlLogs.innerHTML = "Fichiers logs - AUCUN SELECTIONN&Eacute;";

	var lienDdlLog = document.getElementById('lien_ddl_log');
	lienDdlLog.setAttribute("href", "#");
	lienDdlLog.setAttribute("download", "");

	$("#pre_affichage_ddl_log").empty();

	$("#id_popin_ddl_logs").modal("show");
    });

    $('#bouton_dropdown').click(function() {
	
	if($('#bouton_dropdown').attr("aria-expanded") == "false") {

	    var ulDropdownMenu = document.getElementById('ul_dropdown_menu');
	    $(ulDropdownMenu).empty();
	    
	    var fichiersLogs1 = listerContenuRepertoire("../tmp/historiqueLogs/logs1/");
	    if(fichiersLogs1 != null) {
		for(var i = 0; i < fichiersLogs1.length; i++) {
		    var liLien = document.createElement('li');
		    ulDropdownMenu.appendChild(liLien);
		    var aLien = document.createElement('a');
		    aLien.setAttribute("class", "li_lien");
		    aLien.setAttribute("href", "#");
		    aLien.setAttribute("data-fichier", "../tmp/historiqueLogs/logs1/" + fichiersLogs1[i]);
		    aLien.setAttribute("data-repertoire", "../tmp/historiqueLogs/logs1/");
		    aLien.innerHTML = fichiersLogs1[i];
		    liLien.appendChild(aLien);
		}
	    }

	    var liDiviseur = document.createElement('li');
	    liDiviseur.setAttribute("class", "divider");
	    ulDropdownMenu.appendChild(liDiviseur);

	    var fichiersLogs2 = listerContenuRepertoire("../tmp/historiqueLogs/logs2/");
	    if(fichiersLogs2 != null) {
		for(var i = 0; i < fichiersLogs2.length; i++) {
		    var liLien = document.createElement('li');
		    ulDropdownMenu.appendChild(liLien);
		    var aLien = document.createElement('a');
		    aLien.setAttribute("class", "li_lien");
		    aLien.setAttribute("href", "#");
		    aLien.setAttribute("data-fichier", "../tmp/historiqueLogs/logs2/" + fichiersLogs2[i]);
		    aLien.setAttribute("data-repertoire", "../tmp/historiqueLogs/logs2/");
		    aLien.innerHTML = fichiersLogs2[i];
		    liLien.appendChild(aLien);
		}
	    }
	}
    });

    $('#ul_dropdown_menu').on('click', 'li a.li_lien', function() {

	var pTitrePopinDdlLogs = document.getElementById('p_titre_popin_ddl_logs');
	pTitrePopinDdlLogs.innerHTML = "Fichiers logs - " + (this.innerText || this.textContent);
	
	var lienDdlLog = document.getElementById('lien_ddl_log');
	lienDdlLog.setAttribute("href", $(this).attr("data-fichier"));
	lienDdlLog.setAttribute("download", this.innerText || this.textContent);
	lienDdlLog.setAttribute("data-repertoire", $(this).attr("data-repertoire"));
    });

    $('#afficher_log').click(function() {
	
	var preAffichageLog = document.getElementById('pre_affichage_ddl_log');
	$(preAffichageLog).empty();
	var lienDdlLog = document.getElementById('lien_ddl_log');
	preAffichageLog.innerHTML = lireFichier($(lienDdlLog).attr("data-repertoire"), $(lienDdlLog).attr("download"));
    });
    // -----------------------------------------------
    // -----------------------------------------------



    // ----------------------------------------------------
    // Gestion de l'affichage du PopIn de l'état du serveur
    // ----------------------------------------------------
    $('#etat_serveur').click(function() {
	
	var modalBodyEtatServeur = document.getElementById('modal_body_etat_serveur');

	$('#div_etat_serveur').remove();
	var divEtatServeur = document.createElement('div');
	divEtatServeur.setAttribute("id", "div_etat_serveur");
	modalBodyEtatServeur.appendChild(divEtatServeur);
	
	var glyphChargement = document.createElement('p');
	glyphChargement.setAttribute("id", "etat_serveur_glyph_chargement");
	glyphChargement.setAttribute("style", "text-align: center;");
	glyphChargement.innerHTML = "Chargement... <span class='glyphicon glyphicon-refresh gly-spin'></span>"
	divEtatServeur.appendChild(glyphChargement);

	$(divEtatServeur).load("../php/etat_serveur.php", function() {
	    $(glyphChargement).remove();
	});

	$("#id_popin_etat_serveur").modal("show");
    });
    // ----------------------------------------------------
    // ----------------------------------------------------



    // ----------------------------------------------------------
    // Actualisation de l'affichage du PopIn de l'état du serveur
    // ----------------------------------------------------------
    $('#actualiser_etat_serveur').click(function() {
	
	var modalBodyEtatServeur = document.getElementById('modal_body_etat_serveur');

	$('#div_etat_serveur').remove();
	var divEtatServeur = document.createElement('div');
	divEtatServeur.setAttribute("id", "div_etat_serveur");
	modalBodyEtatServeur.appendChild(divEtatServeur);
	
	var glyphChargement = document.createElement('p');
	glyphChargement.setAttribute("id", "etat_serveur_glyph_chargement");
	glyphChargement.setAttribute("style", "text-align: center;");
	glyphChargement.innerHTML = "Chargement... <span class='glyphicon glyphicon-refresh gly-spin'></span>"
	divEtatServeur.appendChild(glyphChargement);

	$(divEtatServeur).load("../php/etat_serveur.php", function() {
	    $(glyphChargement).remove();
	});
    });
    // ----------------------------------------------------------
    // ----------------------------------------------------------



    // -------------------------------------------------
    // Gestion des évènements des boutons du processus 1
    // -------------------------------------------------
    $('#bouton_start_p1').click(function() {
    	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 est d&eacute;j&agrave; en cours...", "span_badge_alerte_p1");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "D&eacute;marrage du processus n&deg;1 en cours...", "span_badge_alerte_p1");
	    deplacementLogs(1);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p1");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		} else {
		    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		}
	    }, 5000);
	}
    });


    $('#bouton_stop_p1').click(function() {

	function confirmerStopP1() {
	    lancerCommande("", "kill -9 " + pidDuProcessus("ext/Soda/soda"));
	    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 s'est arr&ecirc;t&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    }
	}
	function annulerStopP1() {
	    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP1, annulerStopP1]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 est d&eacute;j&agrave; arr&ecirc;t&eacute;.", "span_badge_alerte_p1");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}
    });


    $('#bouton_restart_p1').click(function() {

	function confirmerStopP1() {
	    lancerCommande("", "kill -9 " + pidDuProcessus("ext/Soda/soda"));
	    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 s'est arr&ecirc;t&eacute; avec succ&egrave;s.<br />Red&eacute;marrage du processus en cours...", "span_badge_alerte_p1");
		deplacementLogs(1);
		var dateActu = dateActuelle();
		majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
		lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
		afficherBarreProgression("conteneur_progress_bar_p1");
		setTimeout(function() {
		    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
			afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
			activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    } else {
			afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
			activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    }
		}, 5000);
	    }
	}
	function annulerStopP1() {
	    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

    	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP1, annulerStopP1]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 n'est pas d&eacute;marr&eacute;.<br />D&eacute;marrage en cours...", "span_badge_alerte_p1");
	    deplacementLogs(1);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p1");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		} else {
		    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		}
	    }, 5000);
	}
    });
    // -------------------------------------------------
    // -------------------------------------------------



    // -------------------------------------------------
    // Gestion des évènements des boutons du processus 2
    // -------------------------------------------------
    $('#bouton_start_p2').click(function() {
    	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
	    afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 est d&eacute;j&agrave; en cours...", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	} else {
	    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "D&eacute;marrage du processus n&deg;2 en cours...", "span_badge_alerte_p2");
	    deplacementLogs(2);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p2");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		} else {
		    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		}
	    }, 5000);
	}
    });


    $('#bouton_stop_p2').click(function() {

	function confirmerStopP2() {
	    lancerCommande("", "kill -9 " + (parseInt(pidDuProcessus("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe")) + parseInt(1)));
	    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 s'est arr&ecirc;t&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    }
	}
	function annulerStopP2() {
	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

  	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP2, annulerStopP2]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 est d&eacute;j&agrave; arr&ecirc;t&eacute;.", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}
    });


    $('#bouton_restart_p2').click(function() {

	function confirmerStopP2() {
	    lancerCommande("", "kill -9 " + (parseInt(pidDuProcessus("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe")) + parseInt(1)));
	    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 s'est arr&ecirc;t&eacute; avec succ&egrave;s.<br />Red&eacute;marrage du processus en cours...", "span_badge_alerte_p2");
		deplacementLogs(2);
		var dateActu = dateActuelle();
		majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
		lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
		afficherBarreProgression("conteneur_progress_bar_p2");
		setTimeout(function() {
		    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
			afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
			activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    } else {
			afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
			activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    }
		}, 5000);
	    }
	}
	function annulerStopP2() {
	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

    	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP2, annulerStopP2]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 n'est pas d&eacute;marr&eacute;.<br />D&eacute;marrage en cours...", "span_badge_alerte_p2");
	    deplacementLogs(2);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p2");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		} else {
		    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		}
	    }, 5000);
	}
    });
    // -------------------------------------------------
    // -------------------------------------------------



    // -------------------------------------
    // Gestion simultanée des deux processus
    // -------------------------------------
    $('#bouton_start_p1_p2').click(function() {
    	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
    	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 est d&eacute;j&agrave; en cours...", "span_badge_alerte_p1");
	    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
	   	afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 est d&eacute;j&agrave; en cours...", "span_badge_alerte_p2");
	   	activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
	   	afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "D&eacute;marrage du processus n&deg;2 en cours...", "span_badge_alerte_p2");
		deplacementLogs(2);
		var dateActu = dateActuelle();
		majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    	lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    	afficherBarreProgression("conteneur_progress_bar_p2");
	    	setTimeout(function() {
		    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    	afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    	activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    } else {
		    	afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    	activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    }
	    	}, 5000);	
	    }
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "D&eacute;marrage du processus n&deg;1 en cours...", "span_badge_alerte_p1");
	    deplacementLogs(1);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p1");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "D&eacute;marrage du processus n&deg;2 en cours...", "span_badge_alerte_p2");
		    deplacementLogs(2);
		    var dateActu = dateActuelle();
		    majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    	    afficherBarreProgression("conteneur_progress_bar_p2");
	    	    setTimeout(function() {
			if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    	    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

			} else {
		    	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

			}
	    	    }, 5000);
		} else {
		    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
		    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Impossible de lancer le processus n&deg;2 car le n&deg;1 n'est pas lancé !!", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

		}
	    }, 5000);
	}
    });

    $('#bouton_stop_p1_p2').click(function() {

	function confirmerStopP1P2() {
	    lancerCommande("", "kill -9 " + pidDuProcessus("ext/Soda/soda"));
	    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
		afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 s'est arr&ecirc;t&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 s'est arr&ecirc;t&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    }
	}
	function annulerStopP1P2() {
	    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

   	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP1P2, annulerStopP1P2]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 est d&eacute;j&agrave; arr&ecirc;t&eacute;.", "span_badge_alerte_p1");
	    afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 est d&eacute;j&agrave; arr&ecirc;t&eacute;.", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}
    });

    $('#bouton_restart_p1_p2').click(function() {

	function confirmerStopP1P2() {
	    lancerCommande("", "kill -9 " + pidDuProcessus("ext/Soda/soda"));
	    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
		afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	    } else {
		afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 s'est arr&ecirc;t&eacute; avec succ&egrave;s.<br />Red&eacute;marrage du processus en cours...", "span_badge_alerte_p1");
		afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 s'est arr&ecirc;t&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		deplacementLogs(1);
		var dateActu = dateActuelle();
		majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
		lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
		afficherBarreProgression("conteneur_progress_bar_p1");
		setTimeout(function() {
		    if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
			afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
			afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "D&eacute;marrage du processus n&deg;2 en cours...", "span_badge_alerte_p2");
			deplacementLogs(2);
			var dateActu = dateActuelle();
			majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    		lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    		afficherBarreProgression("conteneur_progress_bar_p2");
	    		setTimeout(function() {
			    if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    		afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
			    } else {
		    		afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    		activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

			    }
	    		}, 5000);
		    } else {
			afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
			afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Impossible de lancer le processus n&deg;2 car le n&deg;1 n'est pas lancé !!", "span_badge_alerte_p2");
			activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
		    }
		}, 5000);
	    }
	}
	function annulerStopP1P2() {
	    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "Le processus n&deg;1 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p1");
	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Le processus n&deg;2 n'a pas pu &ecirc;tre arr&ecirc;t&eacute; !!", "span_badge_alerte_p2");
	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	}

   	desactiverBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);
	if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
	    var nbCoEtablie = lancerCommande(".", "netstat -an | egrep '.*:8888' | awk -F' ' '{print $6}' | sort | uniq -c | tr -d ' ' | grep ESTABLISHED | awk -FE '{print $1}'").split(':')[3];
	    if(nbCoEtablie < 1) {
		nbCoEtablie = 0;
	    }
	    popinDemanderConfirmation("Demande de confirmation", "Vous &ecirc;tes sur le point d'arr&ecirc;ter un processus.<br />Il y a actuellement " + nbCoEtablie + " connexion &eacute;tablie(s) en rapport &agrave; ce processus !!<br />Voulez-vous continuer ?", [confirmerStopP1P2, annulerStopP1P2]);
	} else {
	    afficherAlerte("conteneur_div_alerte_p1", "warning", "Information !", "Le processus n&deg;1 n'est pas d&eacute;marr&eacute;.<br />D&eacute;marrage en cours...", "span_badge_alerte_p1");
	    afficherAlerte("conteneur_div_alerte_p2", "warning", "Information !", "Le processus n&deg;2 n'est pas d&eacute;marr&eacute;.", "span_badge_alerte_p2");
	    deplacementLogs(1);
	    var dateActu = dateActuelle();
	    majLogs.setNomFichiersLogs(0, "logsBdd" + dateActu + ".log");
	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTLabs/", "nohup make sc > /var/www/html/siteGestionProcessus/tmp/logs/logsBdd" + dateActu + ".log");
	    afficherBarreProgression("conteneur_progress_bar_p1");
	    setTimeout(function() {
		if(trouverSiProcessusExiste("ext/Soda/soda") == 1) {
		    afficherAlerte("conteneur_div_alerte_p1", "success", "Information !", "Le processus n&deg;1 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p1");
		    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "D&eacute;marrage du processus n&deg;2 en cours...", "span_badge_alerte_p2");
		    deplacementLogs(2);
		    var dateActu = dateActuelle();
		    majLogs.setNomFichiersLogs(1, "logsServeurCalcul" + dateActu + ".log");
	    	    lancerCommande("/home/scproduction/LMTLabsScetup/software_library/LMTPlugins/GlobalManagerPlugin/", "nohup make all > /var/www/html/siteGestionProcessus/tmp/logs/logsServeurCalcul" + dateActu + ".log");
	    	    afficherBarreProgression("conteneur_progress_bar_p2");
	    	    setTimeout(function() {
			if(trouverSiProcessusExiste("LMTPlugins/GlobalManagerPlugin/ServerPlugin/src/compilations/ServerPlugin_src_main_cpp.exe") == 1) {
		    	    afficherAlerte("conteneur_div_alerte_p2", "success", "Information !", "Le processus n&deg;2 est lanc&eacute; avec succ&egrave;s.", "span_badge_alerte_p2");
		    	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

			} else {
		    	    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;2 !!", "span_badge_alerte_p2");
		    	    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

			}
	    	    }, 5000);
		} else {
		    afficherAlerte("conteneur_div_alerte_p1", "danger", "Information !", "&Eacute;chec de lancement du processus n&deg;1 !!", "span_badge_alerte_p1");
		    afficherAlerte("conteneur_div_alerte_p2", "danger", "Information !", "Impossible de lancer le processus n&deg;2 car le n&deg;1 n'est pas lancé !!", "span_badge_alerte_p2");
		    activerBoutons(['bouton_start_p1', 'bouton_stop_p1', 'bouton_restart_p1', 'bouton_start_p2', 'bouton_stop_p2', 'bouton_restart_p2', 'bouton_start_p1_p2', 'bouton_stop_p1_p2', 'bouton_restart_p1_p2']);

		}
	    }, 5000);
	}
    });
    // -------------------------------------
    // -------------------------------------



    // -----------------------------------------------
    // Permet de switcher entre les différents onglets
    // -----------------------------------------------
    $('#onglet_affichage_logs_1').click(function() {

	if($('#span_affichage_logs_1').attr("data-isclignotant") == "true") {
	    $('#span_affichage_logs_1').attr("data-isclignotant", "false");
	}

	$('#onglet_affichage_logs_1').addClass("active");
	$('#onglet_affichage_logs_2').removeClass("active");
	$('#onglet_terminal').removeClass("active");

	var rechargerTerminal = document.getElementById('recharger_terminal');
	rechargerTerminal.setAttribute("style", "display: none;");

	var divAffichageLogs1 = document.getElementById('div_affichage_logs_1');
	divAffichageLogs1.style.zIndex = 1;
	divAffichageLogs1.style.opacity = 1;
	var divAffichageLogs2 = document.getElementById('div_affichage_logs_2');
	divAffichageLogs2.style.zIndex = 0;
	divAffichageLogs2.style.opacity = 0;
	var divTerminal = document.getElementById('div_terminal');
	divTerminal.style.zIndex = 0;
	divTerminal.style.opacity = 0;
    });

    $('#onglet_affichage_logs_2').click(function() {

	if($('#span_affichage_logs_2').attr("data-isclignotant") == "true") {
	    $('#span_affichage_logs_2').attr("data-isclignotant", "false");
	}

	$('#onglet_affichage_logs_1').removeClass("active");
	$('#onglet_affichage_logs_2').addClass("active");
	$('#onglet_terminal').removeClass("active");

	var rechargerTerminal = document.getElementById('recharger_terminal');
	rechargerTerminal.setAttribute("style", "display: none;");

	var divAffichageLogs1 = document.getElementById('div_affichage_logs_1');
	divAffichageLogs1.style.zIndex = 0;
	divAffichageLogs1.style.opacity = 0;
	var divAffichageLogs2 = document.getElementById('div_affichage_logs_2');
	divAffichageLogs2.style.zIndex = 1;
	divAffichageLogs2.style.opacity = 1;
	var divTerminal = document.getElementById('div_terminal');
	divTerminal.style.zIndex = 0;
	divTerminal.style.opacity = 0;
    });

    $('#onglet_terminal').click(function() {
	
	$('#onglet_affichage_logs_1').removeClass("active");
	$('#onglet_affichage_logs_2').removeClass("active");
	$('#onglet_terminal').addClass("active");

	var rechargerTerminal = document.getElementById('recharger_terminal');
	rechargerTerminal.setAttribute("style", "display: block;");

	var divAffichageLogs1 = document.getElementById('div_affichage_logs_1');
	divAffichageLogs1.style.zIndex = 0;
	divAffichageLogs1.style.opacity = 0;
	var divAffichageLogs2 = document.getElementById('div_affichage_logs_2');
	divAffichageLogs2.style.zIndex = 0;
	divAffichageLogs2.style.opacity = 0;
	var divTerminal = document.getElementById('div_terminal');
	divTerminal.style.zIndex = 1;
	divTerminal.style.opacity = 1;
    });
    // -----------------------------------------------
    // -----------------------------------------------
});
