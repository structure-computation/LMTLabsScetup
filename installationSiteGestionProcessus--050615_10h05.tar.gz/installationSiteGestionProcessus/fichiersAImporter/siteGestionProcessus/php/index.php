<!DOCTYPE html>
<html lang="fr">

  <head>
    <meta charset="UTF-8" />
    <title>Gestion des processus</title>

    <!-- Définie le domaine, code permettant la résolution du problème concernant la communication avec ShellInABox. -->
    <!--script type="text/javascript">
	var url = document.URL;
	var urlSplit = url.split('/');
	document.domain = urlSplit[2];
	</script-->
    
    <script type="text/javascript" src="../js/js/jquery-2.1.4.js"></script>
    <script type="text/javascript" src="../js/script_fonctions.js"></script>

    <!-- Appel du code modifiant le visuel. -->
    <script type="text/javascript" src="../css/bootstrap-3.3.4-dist/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../css/bootstrap-3.3.4-dist/js/bootstrap.js"></script>
    <script type="text/javascript" src="../css/bootstrap-3.3.4-dist/js/dropdown.js"></script>
    <script type="text/javascript" src="../css/style.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-3.3.4-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-3.3.4-dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
  </head>

  <body id="body_page">

    <div id="div_global_page">				

      <!-- Barre haut de page -->
      <div id="div_menu">
	<nav id="nav_menu" class="navbar navbar-inverse">
	  <div class="container-fluid">

	    <div id="div_titre_gauche" class="navbar-header">
	      <a id="lien_home" class="navbar-brand" href=""><span class="glyphicon glyphicon-home"></span> Gestion des processus</a>
	      <script type="text/javascript">
		var url = document.URL;
		var urlSplit = url.split('/');
		document.getElementById('lien_home').href = 'https://' + urlSplit[2];
	      </script>	
	    </div>

	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul id="div_titre_droite" class="nav navbar-nav navbar-right">
		<li id="recharger_terminal" style="display: none;">
		  <a href="#">Recharger le terminal <span class="glyphicon glyphicon-refresh"></span></a>
		</li>
		<div id="div_separateur_navbar"></div>
		<li id="etat_processus">
		  <a href="#">Rafra&icirc;chir l'&eacute;tat des processus <span class="glyphicon glyphicon-tasks"></span></a>
		</li>
		<li id="ddl_logs">
		  <a href="#">T&eacute;l&eacute;charger les fichiers logs <span class="glyphicon glyphicon-file"></span></a>
		</li>
		<li id="etat_serveur">
		  <a href="#">Afficher l'&eacute;tat du serveur <span class="glyphicon glyphicon-hdd"></span></a>
		</li>
	      </ul>
	    </div>

	  </div>
	</nav>
      </div>

      <!-- Partie de gauche -->
      <div id="div_gauche">

	<div id="div_boutons">
	  <div id="boutons_p1_p2">
	    <fieldset id="fieldset_boutons_p1_p2">
	      <legend id="legend_boutons_p1_p2">Processus n&deg;1 & n&deg;2</legend>
	      <button id="bouton_start_p1_p2" class="btn btn-success">Start</button>
	      <button id="bouton_stop_p1_p2" class="btn btn-danger">Stop</button>
	      <button id="bouton_restart_p1_p2" class="btn btn-primary">Restart</button>
	    </fieldset>
	  </div>

	  <div id="boutons_p1">
	    <fieldset id="fieldset_boutons_p1">
	      <legend id="legend_boutons_p1">Processus n&deg;1 : Base de donn&eacute;es</legend>
	      <button id="bouton_start_p1" class="btn btn-success">Start</button>
	      <button id="bouton_stop_p1" class="btn btn-danger">Stop</button>
	      <button id="bouton_restart_p1" class="btn btn-primary">Restart</button>
	      <p id="p_badge_alerte_p1"><span id="span_badge_alerte_p1" class="badge" data-isrunning="false">0 alerte</span></p>
	      <br />
	      <p id="p_etat_p1">&Eacute;tat du processus : <span id="span_etat_p1" class=""></span></p>
	    </fieldset>
	  </div>

	  <div id="boutons_p2">
	    <fieldset id="fieldset_boutons_p2">
	      <legend id="legend_boutons_p2">Processus n&deg;2 : Serveur de calculs</legend>
	      <button id="bouton_start_p2" class="btn btn-success">Start</button>
	      <button id="bouton_stop_p2" class="btn btn-danger">Stop</button>
	      <button id="bouton_restart_p2" class="btn btn-primary">Restart</button>
	      <p id="p_badge_alerte_p2"><span id="span_badge_alerte_p2" class="badge" data-isrunning="false">0 alerte</span></p>
	      <br />
	      <p id="p_etat_p2">&Eacute;tat du processus : <span id="span_etat_p2" class=""></span></p>
	    </fieldset>
	  </div>

	</div>
	
	<div id="div_alerte_et_progress_bar_p1">
	  <div id="conteneur_div_alerte_p1"></div>
	  <div id="conteneur_progress_bar_p1" class="progress" style="display: none;"></div>
	</div>

	<div id="div_alerte_et_progress_bar_p2">
	  <div id="conteneur_div_alerte_p2"></div>
	  <div id="conteneur_progress_bar_p2" class="progress" style="display: none;"></div>
	</div>
	
	<div id="div_footer_gauche">	  
	  <div id="div_trait_horizontal"></div>
	  <p id="p_footer_gauche">*** Site optimisé pour Firefox !! ***</p>
	</div>

      </div>

      <!-- Barre vertical milieu de page -->
      <div id="div_trait_vertical"></div>

      <!-- Partie de droite -->
      <div id="div_droite">

	<!-- Onglets -->
	<ul id="ul_onglets" class="nav nav-tabs nav-justified">
	  <li id="onglet_affichage_logs_1" role="navigation" class="active">
	    <a href="#"><span id="span_affichage_logs_1" class="glyphicon glyphicon-list-alt" data-isclignotant="false"></span> Affichage logs n&deg;1</a>
	  </li>
	  <li id="onglet_affichage_logs_2" role="navigation">
	    <a href="#"><span id="span_affichage_logs_2" class="glyphicon glyphicon-list-alt" data-isclignotant="false"></span> Affichage logs n&deg;2</a>
	  </li>
	  <li id="onglet_terminal" role="navigation">
	    <a href="#"><span class="glyphicon glyphicon-console"></span> Terminal</a>
	  </li>
	</ul>

	<!-- Affichage des fichiers de log et du terminal -->
	<div id="div_logs_et_terminal">

	  <!-- Affichage logs  -->
	  <div id="div_affichage_logs_1">
	    <pre id="pre_affichage_logs_1"></pre>
	  </div>

	  <div id="div_affichage_logs_2">
	    <pre id="pre_affichage_logs_2"></pre>
	  </div>
	  
	  <!-- Terminal -->
	  <div id="div_terminal">
	    <iframe id="iframe_terminal"></iframe>
	    <script type="text/javascript">
	      var url = document.URL;
	      var urlSplit = url.split('/');
	      document.getElementById('iframe_terminal').src = 'https://' + urlSplit[2] + ':6175/';
	    </script>
	  </div>

	</div>

      </div>

    </div>

    <!-- PopIn : Ddl logs -->
    <div id="div_global_ddl_logs"> 
      <div class="modal fade" id="id_popin_ddl_logs" tabindex="-1" role="dialog" aria-labelledby="titrePopUp" aria-hidden="true"> 
	<div id="ddl_logs_css" class="modal-dialog"> 
	  <div id="ddl_logs_content_css" class="modal-content"> 
	    <!-- Titre du popin --> 
	    <div id="modal_header_ddl_logs" class="modal-header"> 
	      <h4 class="modal-title" id="titrePopUp"><p id="p_titre_popin_ddl_logs">Fichiers logs - AUCUN SELECTIONN&Eacute;</p>
		<!-- Croix de fermeture --> 
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> </h4>
	    </div> 
	    <!-- Contenu du popin --> 
	    <div id="modal_body_ddl_logs" class="modal-body">
	      <pre id="pre_affichage_ddl_log"></pre>
	    </div>
	    <!-- Pied de page du popin --> 
	    <div id="modal_footer_ddl_logs" class="modal-footer"> 
	      <div id="div_btn_group" class="btn-group pull-left dropup">
		<a id="lien_ddl_log" href="#" class="btn btn-danger">T&eacute;l&eacute;charger <span class="glyphicon glyphicon-download-alt"></span></a>
		<button type="button" id="bouton_dropdown" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
		  <span class="caret"></span>
		</button>
		<ul id="ul_dropdown_menu" class="dropdown-menu" role="menu"></ul>
	      </div>
	      <button id="afficher_log" class="btn btn-warning pull-left">Afficher <span class="glyphicon glyphicon-sunglasses"></span></button>
	      <button class="btn btn-info pull-right" data-dismiss="modal" aria-hidden="true">Fermer</button>
	    </div> 
	  </div> 
	</div> 
      </div>
    </div>
    
    <!-- PopIn : Etat du serveur -->
    <div id="div_global_etat_serveur"> 
      <div class="modal fade" id="id_popin_etat_serveur" tabindex="-1" role="dialog" aria-labelledby="titrePopUp" aria-hidden="true"> 
	<div class="modal-dialog"> 
	  <div class="modal-content"> 
	    <!-- Titre du popin --> 
	    <div class="modal-header"> 
	      <h4 class="modal-title" id="titrePopUp">&Eacute;tat du serveur
		<!-- Croix de fermeture --> 
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> </h4>
	    </div> 
	    <!-- Contenu du popin --> 
	    <div id="modal_body_etat_serveur" class="modal-body"></div>
	    <!-- Pied de page du popin --> 
	    <div class="modal-footer"> 
	      <button class="btn btn-info" data-dismiss="modal" aria-hidden="true">Fermer</button>
	      <button id="actualiser_etat_serveur" class="btn btn-warning">Actualiser</button>
	    </div> 
	  </div> 
	</div> 
      </div>
    </div>

  </body>

</html>
