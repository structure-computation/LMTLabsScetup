<?php

class ServerPing {

    private $output = array();
    private $avg = 0;
    private $min = 0;
    private $max = 0;
 
    public function send($server, $repeat) { // server : nom de domaine ou ip, et repeat : nombre de test

        if($repeat == 0) {
            throw new Exception("La variable repeat ne peut être à zero !!!");
        }
 
        $cmd = 'ping -c '.$repeat.' '.$server;
        exec($cmd, $this->output);

        if(count($this->output) > 2) {
            $toparse=$this->output[count($this->output)-1];
            if(strpos($toparse, 'rtt min/avg/max/mdev =') !== false) {
                $str = trim(substr($toparse, 23));
                $vals = explode("/", $str);
 
                if(count($vals) >= 4) {
                    $this->min = $vals[0];
                    $this->max = $vals[2];
                    $this->avg = $vals[1];
                }
            }
        }
    }
 
    /* Afficher le détail du ping */
    public function getOutput() {
        return implode("\n", $this->output);
    }
 
    /* Connaitre l'état du serveur */
    public function isAlive() {
        if ($this->avg == 0) {
            return false;
        }  else {
            return true;
        }
    }

    /* Temps minimum de réponse */    
    public function getMin() {
        return $this->min;
    }
 
    /* Temps maximum de réponse */
    public function getMax() {
        return $this->max;
    }
 
    /* Temps moyen de réponse */
    public function getAverage() {
        return $this->avg;
    } 
}


$serverPing = new ServerPing();
$serverPing->send("138.231.77.189", 5);
if($serverPing->isAlive()) {
    echo "Le serveur <span style='color: green'>fonctionne</span> !!!";
} else {
    echo "Le serveur est <span style='color: red'>down</span> !!!";
}
echo '<br />';
echo "Le temps moyen de r&eacute;ponse est : ".$serverPing->getAverage()." ms.";
echo "<br /> D&eacute;tail du ping : <br>---------------------------<br><pre>".$serverPing->getOutput()."</pre>";

?>