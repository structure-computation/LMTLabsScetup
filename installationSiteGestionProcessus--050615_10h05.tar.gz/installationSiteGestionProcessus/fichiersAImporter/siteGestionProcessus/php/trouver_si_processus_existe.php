<?php

	if(isset($_POST['nomProcessus'])) {
	
	   $nomFichier = '../tmp/liste_processus.txt';

	   $cmd = shell_exec('ps -ef > '.$nomFichier); // Execution de la commande permettant de lister les processus en cours.
	
	   $fichier = file_get_contents($nomFichier); // Ouverture du fichier.
	   $isMatch = preg_match("#".$_POST['nomProcessus']."#", $fichier); // Retourne 1 si la chaîne est trouvé, 0 sinon.
	   echo $isMatch;
	}

?>